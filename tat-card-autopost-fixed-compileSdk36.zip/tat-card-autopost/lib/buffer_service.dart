import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;

class BufferService {
  // --dart-define দিয়ে দিবা, কোডে সরাসরি Key রাখবা না
  static const apiKey = 'NHtP0O78GDbRaA7aTVQ9QWN6O3_2X2cYdFWOLNWZVfo';
  static const channelId = '6af0e16b62b70b94b0c425f1';
  static const imgbbKey = '4ce7321f77ff69938348c505788e3c81';

  // ১. JPG Bytes -> Public URL
  static Future<String> uploadToImgBB(Uint8List jpgBytes) async {
    final res = await http.post(
      Uri.parse('https://api.imgbb.com/1/upload?key=$imgbbKey'),
      body: {'image': base64Encode(jpgBytes)},
    );
    final data = jsonDecode(res.body);
    if (data['success'] != true) throw Exception('Image upload failed');
    return data['data']['display_url'] as String;
  }

  // ২. Buffer দিয়ে ShareNow
  static Future<void> publishNow({
    required String text,
    required String imageUrl,
  }) async {
    // jsonEncode দিয়ে বাংলা টেক্সটের কোটেশন সমস্যা থেকে বাঁচছি
    final query = '''
    mutation CreatePost {
      createPost(input: {
        text: ${jsonEncode(text)},
        channelId: "$channelId",
        schedulingType: automatic,
        mode: shareNow,
        assets: [{ image: { url: ${jsonEncode(imageUrl)} } }],
        metadata: {
          facebook: { type: post }
        }
      }) {
        ... on PostActionSuccess { post { id text } }
        ... on MutationError { message }
      }
    }
    ''';

    final res = await http.post(
      Uri.parse('https://api.buffer.com'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: jsonEncode({'query': query}),
    );

    final body = jsonDecode(res.body);
    if (body['data']?['createPost']?['message'] != null) {
      throw Exception(body['data']['createPost']['message']);
    }
  }
}