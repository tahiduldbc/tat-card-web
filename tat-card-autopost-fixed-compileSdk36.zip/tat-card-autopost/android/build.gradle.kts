allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

// Keep Flutter's build output in the project-level build directory.
val newBuildDir = rootProject.layout.projectDirectory.dir("../build")
rootProject.layout.buildDirectory.set(newBuildDir)

subprojects {
    layout.buildDirectory.set(newBuildDir.dir(name))

    // Keep Android library plugins (for example file_picker) on the
    // same compileSdk required by their AndroidX dependencies.
    plugins.withId("com.android.library") {
        extensions.configure<com.android.build.api.dsl.LibraryExtension> {
            compileSdk = 36
        }
    }
}

subprojects {
    evaluationDependsOn(":app")
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
